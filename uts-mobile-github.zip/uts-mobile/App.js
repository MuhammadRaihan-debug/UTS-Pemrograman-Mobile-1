import React, { useState } from "react";
import { View, StatusBar } from "react-native";

import Login from "./screens/Login";
import Home from "./screens/Home";

export default function App() {
  const [user, setUser] = useState(null);

  const handleLogin = (userData) => {
    setUser(userData);
  };

  const handleLogout = () => {
    setUser(null);
  };

  return (
    <View style={{ flex: 1 }}>
      <StatusBar
        backgroundColor="#FFFFFF"
        barStyle="dark-content"
      />

      {user === null ? (
        <Login onLogin={handleLogin} />
      ) : (
        <Home
          user={user}
          onLogout={handleLogout}
        />
      )}
    </View>
  );
}