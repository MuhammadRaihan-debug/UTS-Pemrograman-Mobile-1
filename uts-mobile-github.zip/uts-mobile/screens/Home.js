import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
} from "react-native";

export default function Home({ user, onLogout }) {
  const menus = ["TUGAS", "JADWAL", "ABSENSI", "PENGUMUMAN"];

  const handleMenu = (menu) => {
    Alert.alert(menu, "Kamu memilih " + menu);
  };

  const handleLogout = () => {
    Alert.alert(
      "Konfirmasi Logout",
      "Apakah kamu yakin ingin logout?",
      [
        {
          text: "Batal",
          style: "cancel",
        },
        {
          text: "Logout",
          onPress: onLogout,
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.title}>HOME PAGE</Text>

        <View style={styles.welcomeBox}>
          <Text style={styles.welcome}>
            WELCOME, {user.nama.toUpperCase()}
          </Text>
          <Text style={styles.email}>{user.email}</Text>
        </View>

        <View style={styles.menuContainer}>
          {menus.map((menu, index) => (
            <TouchableOpacity
              key={index}
              style={styles.menuButton}
              onPress={() => handleMenu(menu)}
            >
              <Text style={styles.menuText}>{menu}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity
          style={styles.logoutButton}
          onPress={handleLogout}
        >
          <Text style={styles.logoutText}>
            TOMBOL LOGOUT
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  content: {
    flexGrow: 1,
    paddingHorizontal: 30,
    paddingTop: 55,
    alignItems: "center",
  },
  title: {
    fontSize: 20,
    color: "#222222",
    marginBottom: 25,
  },
  welcomeBox: {
    width: "100%",
    minHeight: 75,
    borderWidth: 1,
    borderColor: "#777777",
    justifyContent: "center",
    paddingHorizontal: 12,
    marginBottom: 28,
  },
  welcome: {
    fontSize: 14,
    color: "#333333",
  },
  email: {
    fontSize: 11,
    color: "#777777",
    marginTop: 5,
  },
  menuContainer: {
    width: "100%",
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    rowGap: 10,
  },
  menuButton: {
    width: "48%",
    height: 48,
    borderWidth: 1,
    borderColor: "#777777",
    justifyContent: "center",
    alignItems: "center",
  },
  menuText: {
    fontSize: 13,
    color: "#333333",
  },
  logoutButton: {
    minWidth: 140,
    height: 38,
    borderWidth: 1,
    borderColor: "#555555",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 40,
  },
  logoutText: {
    fontSize: 12,
    color: "#222222",
  },
});