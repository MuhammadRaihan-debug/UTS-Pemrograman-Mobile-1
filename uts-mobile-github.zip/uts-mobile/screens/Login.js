import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from "react-native";

export default function Login({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
    if (!email.trim() || !password) {
      Alert.alert("Peringatan", "Email dan password harus diisi!");
      return;
    }

    if (
      email.trim().toLowerCase() === "mahasiswa@gmail.com" &&
      password === "123456"
    ) {
      onLogin({
        nama: "Mahasiswa",
        email: email.trim(),
      });
    } else {
      Alert.alert("Login Gagal", "Email atau password salah!");
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.logo}>MY APP</Text>
        <Text style={styles.nama}>Muhammad Raihan</Text>

        <TextInput
          style={styles.input}
          placeholder="INPUT EMAIL"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
        />

        <TextInput
          style={styles.input}
          placeholder="INPUT PASSWORD"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />

        <TouchableOpacity
          style={styles.button}
          onPress={handleLogin}
        >
          <Text style={styles.buttonText}>TOMBOL LOGIN</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
    justifyContent: "center",
    paddingHorizontal: 35,
  },
  content: {
    width: "100%",
  },
  logo: {
    fontSize: 25,
    textAlign: "center",
    color: "#222222",
    fontWeight: "bold",
  },
  nama: {
    fontSize: 17,
    textAlign: "center",
    marginTop: 8,
    marginBottom: 45,
    color: "#444444",
  },
  input: {
    height: 45,
    borderWidth: 1,
    borderColor: "#777777",
    paddingHorizontal: 12,
    marginBottom: 14,
    fontSize: 14,
    color: "#222222",
  },
  button: {
    alignSelf: "center",
    borderWidth: 1,
    borderColor: "#555555",
    paddingHorizontal: 18,
    height: 38,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 2,
  },
  buttonText: {
    fontSize: 12,
    color: "#222222",
  },
});